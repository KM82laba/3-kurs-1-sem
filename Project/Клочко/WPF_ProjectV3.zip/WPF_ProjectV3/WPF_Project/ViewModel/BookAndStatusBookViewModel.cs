﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Project
{
    public class BookAndStatusBookViewModel
    {
        public BooksViewModel BooksViewModel { get; set; }
        public UserBooksViewModel UserBooksViewModel { get; set; }
    }
}
