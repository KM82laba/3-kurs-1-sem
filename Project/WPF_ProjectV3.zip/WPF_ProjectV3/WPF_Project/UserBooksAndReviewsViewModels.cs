﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Project
{
    public class UserBooksAndReviewsViewModels
    {
        public ReviewsViewModel ReviewsViewModel { get; set; }
        public UserBooksViewModel UserBooksViewModel { get; set; }

    }
}
