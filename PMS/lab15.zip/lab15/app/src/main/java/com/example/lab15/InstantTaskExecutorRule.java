package com.example.lab15;

public class InstantTaskExecutorRule {
}
