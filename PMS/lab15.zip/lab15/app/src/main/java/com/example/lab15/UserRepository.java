package com.example.lab15;

public class UserRepository {
    public Object getUsers() {
        return new Object();
    }
}
